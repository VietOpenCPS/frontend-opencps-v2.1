import React from 'react';

const App = () => (
  <p>Hello world!</p>
);

export default App;
