import Vue from 'vue/dist/vue.min.js'

export const eventBus = new Vue()