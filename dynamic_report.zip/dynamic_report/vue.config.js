module.exports = {
    runtimeCompiler: true
  }
  