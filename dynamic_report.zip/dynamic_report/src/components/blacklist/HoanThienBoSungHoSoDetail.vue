<template>
  <div>
    9816313910231203
  </div>
</template>

<script>
export default {
  props: ['index'],
  data: () => ({
  })
}
</script>
