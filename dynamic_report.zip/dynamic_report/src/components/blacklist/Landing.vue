<template>
  <div>
   2222222
  </div>
</template>

<script>
export default {
  data: () => ({
  })
}
</script>
