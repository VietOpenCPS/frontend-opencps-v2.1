// var doLogin = function(){
//         var name = $("#userName").val()
//         var password = $("#password").val()
//         $.ajax({
//             url: '/o/v1/opencps/login',
//             dataType: 'json',
//             type: 'POST',
//             headers: {
//               'Authorization': 'BASIC ' + window.btoa(name + ":" + password),
//             },
//             success: function (response) {
//                 if (response === 'ok' || (response !== '' && response !== 'ok' && response !== 'captcha' && response !== 'lockout')) {
//                     window.location.href = "https://kiemthu-mt-gov-vn-9001.fds.vn/web/kho-dien-tu#/so-hoa-giay-to"
//                 }
//             },
//             error: function (xhr) {

//             }
//         })
//     };

var doLogin = function () {
		var name = $("#userName").val()
        var password = $("#password").val()
		var pAuth = Liferay.authToken
		$.post("?p_p_id=com_liferay_login_web_portlet_LoginPortlet&p_p_lifecycle=1&p_p_state=maximized&p_p_mode=view&_com_liferay_login_web_portlet_LoginPortlet_javax.portlet.action=%2Flogin%2Flogin&_com_liferay_login_web_portlet_LoginPortlet_mvcRenderCommandName=%2Flogin%2Flogin&p_auth=" + pAuth,
		{
		"_com_liferay_login_web_portlet_LoginPortlet_login": name,
		"_com_liferay_login_web_portlet_LoginPortlet_password": password
		},
		function(data, statusText, xhr){
			  $.ajax({
				url: '/o/rest/v2/users/login',
				dataType: 'json',
				type: 'GET',
				headers: {
				  'Token': pAuth
				},
				success: function (response) {
					console.log("response", response)
					if (response && response.length) {
						var role = response.find(function (item) {
						  return item.role === 'User'
						})
						if (role) {
							window.location.href = "/web/kho-dien-tu/kho-ban-sao-dien-tu"
						} else {
							Toastify({
							  text: "Tên đăng nhập hoặc mật khẩu không chính xác",
							  duration: 3000,
							  newWindow: true,
							  close: true,
							  gravity: "top",
							  position: "center",
							  backgroundColor: "linear-gradient(to right, #f53555, #f53555)",
							}).showToast();
						}
					} else {
						Toastify({
						  text: "Tên đăng nhập hoặc mật khẩu không chính xác",
						  duration: 3000,
						  newWindow: true,
						  close: true,
						  gravity: "top",
						  position: "center",
						  backgroundColor: "linear-gradient(to right, #f53555, #f53555)",
						}).showToast();
					}
				},
				error: function (xhr) {
					Toastify({
					  text: "Lỗi đăng nhập",
					  duration: 3000,
					  newWindow: true,
					  close: true,
					  gravity: "top",
					  position: "center",
					  backgroundColor: "linear-gradient(to right, #f53555, #f53555)",
					}).showToast();
				}
			})
		})
	}
    $( "#btn-submit" ).bind( "click", doLogin);