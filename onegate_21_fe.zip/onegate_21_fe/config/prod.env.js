module.exports = {
  NODE_ENV: JSON.stringify('production')
}
